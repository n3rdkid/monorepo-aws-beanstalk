module.exports = {
    distDir: "../../build"
};
  