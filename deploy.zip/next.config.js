module.exports = {
    distDir: "build"
};
  